package com.my.PDFTool;

/**
 * @author: mayong
 * @createAt: 2020/08/28
 */
public interface CompletionCall<Input> {
    public void call(Input value);
}
