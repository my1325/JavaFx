import com.my.PDFConvertUI.PDFConvertApplication;
import javafx.application.Application;

/**
 * @author: mayong
 * @createAt: 2020/08/28
 */
public class MainApplication {

    public static void main(String[] args) {
        Application.launch(PDFConvertApplication.class);
    }
}
